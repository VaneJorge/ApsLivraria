package com.example.aps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button botaoIncluir = (Button)findViewById(R.id.btnIncluir);
        final Button botaoConsultar = (Button)findViewById(R.id.btnConsultar);

        botaoIncluir.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                BancoController crud = new BancoController(getBaseContext());
                EditText nome = (EditText)findViewById(R.id.txtNome);
                EditText endereco = (EditText)findViewById(R.id.txtEndereco);
                EditText celular = (EditText)findViewById(R.id.txtCelular);
                EditText email = (EditText)findViewById(R.id.txtEmail);
                EditText cpf = (EditText)findViewById(R.id.txtCpf);
                EditText dataNascimento = (EditText)findViewById(R.id.txtDataNascimento);
                EditText categoriaLeitor = (EditText)findViewById(R.id.txtCategoriaLeitor);

                String nomeString = nome.getText().toString();
                String enderecoString = endereco.getText().toString();
                String celularString = celular.getText().toString();
                String emailString = email.getText().toString();
                String cpfString = cpf.getText().toString();
                String dataNascimentoString = dataNascimento.getText().toString();
                String categoriaLeitorString = categoriaLeitor.getText().toString();
                String resultado;

                resultado = crud.insereDado(nomeString, enderecoString, celularString, emailString, cpfString, dataNascimentoString, categoriaLeitorString);

                Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG).show();
            }
        });

        botaoConsultar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, ConsultaDados.class);
                startActivity(intent);
            }
        });
    }
}
