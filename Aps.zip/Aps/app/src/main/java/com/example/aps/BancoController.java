package com.example.aps;

import android.content.ContentValues;
import android.database.Cursor;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.Date;

public class BancoController {

    private SQLiteDatabase db;
    private CriaBanco banco;

    public BancoController(Context context) {
        banco = new CriaBanco(context);
    }

    public String insereDado(String nome, String endereco, String celular, String email, String cpf, String dataNascimento, String categoriaLeitor) {
        ContentValues valores;
        long resultado;

        db = banco.getWritableDatabase();
        valores = new ContentValues();
        valores.put(CriaBanco.getNOME(), nome);
        valores.put(CriaBanco.getENDERECO(), endereco);
        valores.put(CriaBanco.getCELULAR(), celular);
        valores.put(CriaBanco.getEMAIL(), email);
        valores.put(CriaBanco.getCPF(), cpf);
        valores.put(CriaBanco.getDataNasc(), dataNascimento);
        valores.put(CriaBanco.getCatLeitor(), categoriaLeitor);

        resultado = db.insert(CriaBanco.getTabelaCliente(), null, valores);
        db.close();

        if (resultado == -1) {
            return "Erro ao inserir o cliente";
        } else {
            return "Cliente inserido com sucesso";
        }

    }

    public Cursor carregaDados(){
        Cursor cursor;
        String[] campos = {CriaBanco.getID(), CriaBanco.getNOME()};
        db = banco .getReadableDatabase();
        cursor = db.query(CriaBanco.getTabelaCliente(), campos, null, null, null, null, null, null);

        if(cursor != null){
            cursor.moveToFirst();
        }

        db.close();
        return cursor;
    }
}