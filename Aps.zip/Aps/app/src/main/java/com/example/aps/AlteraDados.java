package com.example.aps;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AlteraDados extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_altera_dados);
    }
}
